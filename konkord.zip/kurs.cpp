/*
#################################################################################
#                           Konkord 						#								#
#                      Version 0.0.2009.04.19					#							#
#               This program was created for learning words			#						#
#	 		from different languages.				#							#
#										#										#
#    Copyright(C) 2009 Sławomir Domagała					#					#
#										#										#
#    This program is free software: you can redistribute it and/or modify	#
#    it under the terms of the GNU General Public License as published by	#
#    the Free Software Foundation, either version 3 of the License, or		#
#    (at your option) any later version.					#					#
#										#										#
#    This program is distributed in the hope that it will be useful,		#
#    but WITHOUT ANY WARRANTY; without even the implied warranty of		#
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the		#
#    GNU General Public License for more details.				#				#
#										#										#
#    You should have received a copy of the GNU General Public License		#
#    along with this program.  If not, see <http://www.gnu.org/licenses/>	#
#										#										#
#    E-mail: godlark@gmail.com							#						#
#################################################################################		
*/
#include "kurs.hpp"

using namespace std;
typedef unsigned short int ushort;

string Word::getFirst() const
{
	return this->first;
}
string Word::getSecond() const
{
	return this->second;
}
unsigned int Word::getTime_lastud() const
{
	return this->time_lastud;
}
ushort Word::getHralev() const
{
	return this->hralev;
}
ushort Word::getOplev() const
{
	return this->oplev;
}
void Word::setFirst(string _first)
{
	first = _first;
}
void Word::setSecond(string _second)
{
	second = _second;
}
void Word::setTime_lastud(unsigned int time_lastud)
{
	this->time_lastud = time_lastud;
}
void Word::setHralev(int _hralev)
{
	if(_hralev > MAX_HRALEV)hralev = MAX_HRALEV;
	else if(_hralev < MIN_HRALEV)hralev = MIN_HRALEV;
	else hralev = _hralev;
}
void Word::setOplev(ushort _oplev)
{
	if(_oplev > MAX_OPLEV)oplev = MAX_OPLEV;
	else if(_oplev < MIN_OPLEV)oplev = MIN_OPLEV;
	else oplev = _oplev;
}
void Word::setOplev(time_t nowTime)
{
	unsigned int max_way_time = ceil((oplev*86400)/hralev);
	unsigned int way_time = (unsigned int)nowTime - time_lastud;
	ushort old_oplev = oplev;	
	if(way_time > max_way_time)way_time = max_way_time;	
	setOplev((ushort)(oplev-((way_time*hralev)/86400)));
	if(oplev != old_oplev)setTime_lastud(nowTime);
}
Word::Word(string _first, string _second)
{
	first = _first;
	second = _second;
	hralev = MIN_HRALEV;
	oplev = MIN_OPLEV;
	time_lastud = 0;
}
Word::Word()//Word("","")
{
	first = "";
	second = "";
	hralev = MIN_HRALEV;
	oplev = MIN_OPLEV;
	time_lastud = 0;
}
Word Word::newWord(string first, string second)//trzeba to wykorzystać, świeżo dodana funkcja
{
	Word word(first, second);
	return word;
}

Kurs::~Kurs() {
    for(int i = 0; i < wordl1.size(); i++) {
        wordl1[i]->deleteAllMeanings();
        delete wordl1[i];
    }
    for(int i = 0; i < wordl2.size(); i++) {
        wordl2[i]->deleteAllMeanings();
        delete wordl2[i];
    }
}
void Kurs::addSingleWords(const vector<string> &spellings, const vector<string> &sounds, const vector<string> &meanings_spelling, const vector<string> &meanings_sound) {
    SingleWord *tempsw;
    if(spellings.size() != sounds.size() || meanings_spelling.size() != meanings_sound.size())throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
    for(ushort i = 0; i < spellings.size(); i++) {
        tempsw = new SingleWord(spellings[i], sounds[i]);
        wordl1.push_back(tempsw);
    }
    for(ushort i = 0; i < meanings_spelling.size(); i++) {
        tempsw = new SingleWord(meanings_spelling[i], meanings_sound[i]);
        wordl2.push_back(tempsw);
        for(ushort j = wordl1.size() - sounds.size(); j < wordl1.size(); j++) {
            cout << wordl2[wordl2.size()-1]->getSpelling() << endl;
            cout << wordl1[j]->getSpelling() << endl;
            if(SingleWord::connectSingleWords(wordl2[wordl2.size()-1], wordl1[j], 0, 0)) {//łączy ostatnio dodane słowo dodane do wordl2 z...
                numberConnections++;
            }
        }
    }
    qAllSingleWords = wordl1.size() + wordl2.size();
    ifChangeKurs = true;
}
void Kurs::addSingleWord(const SingleWord &singleWord, ushort where) {
    if(where == 0)wordl1.push_back(new SingleWord(&singleWord));
    else wordl2.push_back(new SingleWord(&singleWord));
    qAllSingleWords = wordl1.size() + wordl2.size();
    ifChangeKurs = true;
}
void Kurs::connectSingleWords(ushort number1, ushort number2) {
    if(number1 >= wordl1.size() || (number2 >= wordl1.size()+wordl2.size() || number2 < wordl1.size()))throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
    if(SingleWord::connectSingleWords(wordl1[number1], wordl2[number2-wordl1.size()], 0, 0)) {
        numberConnections++;
        ifChangeKurs = true;
    }
    //else jakieś powiadomienie
}
void Kurs::disconnectSingleWords(ushort number1, ushort number2) {
    if(number1 >= wordl1.size() || (number2 >= wordl1.size()+wordl2.size() || number2 < wordl1.size()))throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
    if(SingleWord::disconnectSingleWords(wordl1[number1], wordl2[number2-wordl1.size()])) {
        numberConnections--;
        ifChangeKurs = true;
    }
    //else jakieś powiadomienie
}
void Kurs::delSingleWord(ushort number) {
    if(number < wordl1.size()) {
        wordl1[number]->deleteAllMeanings();
        if(wordl1[number]->getOplev() != 0)qKnownSingleWords--;
        delete wordl1[number];
        wordl1.erase(wordl1.begin() + number);
    }
    else if(number < wordl1.size() + wordl2.size()) {
        wordl2[number-wordl1.size()]->deleteAllMeanings();
        if(wordl2[number-wordl1.size()]->getOplev() != 0)qKnownSingleWords--;
        delete wordl2[number-wordl1.size()];
        wordl2.erase(wordl2.begin() + number-wordl1.size());
    }
    else throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
    qAllSingleWords = wordl1.size() + wordl2.size();
    ifChangeKurs = true;
}
vector<ushort> Kurs::findWord_new(boost::regex searched_string) const
{
	vector<ushort> found_words;
	for(ushort i = 0; i < wordl1.size(); i++)
	{
		if(regex_match(wordl1[i]->getSpelling(), searched_string))
		{
			found_words.push_back(i);
		}
	}
        for(ushort i = 0; i < wordl2.size(); i++)
	{
		if(regex_match(wordl2[i]->getSpelling(), searched_string))
		{
			found_words.push_back(i+wordl1.size());
		}
	}
	return found_words;
}
vector<ushort> Kurs::getConnectionsToRepetition(ushort &howMany) const {
    ushort AhowMany = 0;
    priority_queue<ConnectionToRepetition, vector<ConnectionToRepetition>, compareConnections> Q;
    ConnectionToRepetition ctr;
    time_t nowTime = time(NULL);
    for(ushort i = 0; i < wordl1.size(); i++) {
        ushort howManyConnections = wordl1[i]->getNumberMeanings();
        for(ushort j = 0; j < howManyConnections; j++) {
            ushort temp = wordl1[i]->getTimeNextRepetition(j, repetitionsTime);
            if(temp <= (unsigned int)nowTime && wordl1[i]->getTimeLastRepetition(j) != 0) { //zmienieć na jakieś isKnown
                ctr.nr_word = i;
                ctr.nr_connection = j;
                ctr.nextTimeOfRepetition = temp;
                Q.push(ctr);
                AhowMany++;
            }
        }
    }
    vector<ushort> connectionsToRepetition;
    if(AhowMany < howMany)howMany = AhowMany;
    for(ushort i = 0; i < howMany; i++) {
        connectionsToRepetition.push_back(Q.top().nr_word);
        connectionsToRepetition.push_back(Q.top().nr_connection);
        Q.pop();
    }
    return connectionsToRepetition;
}
vector<ushort> Kurs::getUnknownSingleWords(ushort quantityOfWords) const {
	//if(quantityOfWords > qAllWords - qKnownWords)quantityOfWords = qAllWords - qKnownWords;
	vector<ushort> wordsToAsk;
        time_t lasttime = time(NULL);
	for(ushort i = 0, j = 0; i < qAllSingleWords && j < quantityOfWords; i++) {
                if(i < wordl1.size()) {
                    if(!wordl1[i]->isKnown()) {
			wordsToAsk.push_back(i);
                        ushort number_connections = wordl1[i]->getNumberMeanings();
                        for(ushort k = 0; k < number_connections; k++) {
                            wordl1[i]->setTimeLastRepetition(k, lasttime);
                        }
			j++;
                    }
                }
                else {
                    if(!wordl2[i-wordl1.size()]->isKnown()) {
			wordsToAsk.push_back(i);
                        ushort number_connections = wordl2[i-wordl1.size()]->getNumberMeanings();
                        for(ushort k = 0; k < number_connections; k++) {
                            wordl2[i-wordl1.size()]->setTimeLastRepetition(k, lasttime);
                        }
			j++;
                    }
                }
	}
	return wordsToAsk;
}
vector<ushort> Kurs::getKnownSingleWords(ushort quantityOfWords) const {
	if(quantityOfWords > qKnownSingleWords)quantityOfWords = qKnownSingleWords;
	priority_queue<SingleWordAndIndex, vector<SingleWordAndIndex>, compareSingleWords> Q;
	SingleWordAndIndex swani;
	for(ushort i = 0; i < qAllSingleWords; i++)
	{
                if(i < wordl1.size()) {
                    if(wordl1[i]->isKnown())
                    {
			swani.sword = wordl1[i];
			swani.index = i;
			Q.push(swani);
                    }
                }
                else {
                    if(wordl2[i-wordl1.size()]->isKnown()){
			swani.sword = wordl2[i-wordl1.size()];
			swani.index = i;
			Q.push(swani);
                    }
                }
	}
	vector<ushort> wordsToAsk;
        Q.pop();
	for(ushort i = 0; i < quantityOfWords; i++)
	{
		swani = Q.top();
                wordsToAsk.push_back(swani.index);
		Q.pop();
	}
	return wordsToAsk;
}
void Kurs::increaseQKnownSingleWords(short int quantity) {
        qKnownSingleWords += quantity;
}
ushort Kurs::getQAllSingleWords() const {
	return qAllSingleWords;
}
ushort Kurs::getQKnownSingleWords() const {
	return qKnownSingleWords;
}
ushort Kurs::getQSingleWords_1() const {
    return wordl1.size();
}
ushort Kurs::getQSingleWords_2() const {
    return wordl2.size();
}
SingleWord const* Kurs::getSingleWord(ushort number) const
{
        if(number >= qAllSingleWords)throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
        return number < wordl1.size() ? wordl1[number] : wordl2[number-wordl1.size()];
}
vector<SingleWord const*> Kurs::getSingleWords(ushort from, ushort _to) const//todo
{
	vector<SingleWord const*> _words;
        if(from >= qAllSingleWords || _to >= qAllSingleWords)throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
        else if(_to < from && _to != 0)throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
        if(_to == 0)_to = qAllSingleWords;
        if(from < wordl1.size()) {
            if(_to < wordl1.size())_words.insert(_words.begin(), wordl1.begin()+from, wordl1.begin()+_to);
            else {
                _words.insert(_words.begin(), wordl1.begin()+from, wordl1.begin()+wordl1.size());
                _words.insert(_words.begin(), wordl2.begin(), wordl2.begin()+_to-wordl1.size());
            }
        }
        else {
            _words.insert(_words.begin(), wordl2.begin()+from-wordl1.size(), wordl2.begin()+_to-wordl1.size());
        }
        for(ushort i = 0; i < _words.size(); i++) {
            cout << i << "\t" <<_words[i]->getSpelling() << endl;
        }
        cout << "\n\n\n\n" << endl;
        return _words;
}
void Kurs::repairSingleWord(ushort word_number, double czas, double oplev) {
        SingleWord *sword = word_number < wordl1.size() ? wordl1[word_number] : wordl2[word_number-wordl1.size()];
        czas /= sword->getSpelling().length();
	
	if(oplev > 1000)oplev = 1000;
	oplev /= czas;
        
        if(oplev == 0 && sword->getOplev() != 0)increaseQKnownSingleWords(-1);
        if(oplev != 0 && sword->getOplev() == 0)increaseQKnownSingleWords(1);
        
	int procent = (((sword->getOplev()*1000)/oplev)-1000)/2;
	
	sword->setHralev((sword->getHralev()*procent)/1000+sword->getHralev());
	sword->setOplev((ushort)oplev);
	sword->setTime_lastud(time(NULL));
	
	ifChangeKurs = true;
}
void Kurs::repairSingleWord_new(ushort word_number, time_t czas, vector<double> oplev_connections) {
    SingleWord *sword = word_number < wordl1.size() ? wordl1[word_number] : wordl2[word_number-wordl1.size()];
    //dodać coś z czasm i pisaniem na komputerze
    double max_oplev = 20;
    if(oplev_connections.size() < sword->getNumberMeanings())throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
    time_t nowTime = time(NULL);
    double temp;
    for(ushort i = 0; i < sword->getNumberMeanings(); i++) {
        if(oplev_connections[i] > 20)oplev_connections[i] = 20;
        temp = (double)((double)(sword->getTimeNextRepetition(i, repetitionsTime)-(unsigned int)nowTime)/(double)repetitionsTime[sword->getWhichRepetition(i)]);
        if(temp < 0)oplev_connections[i] *= 1.0-temp;
        else oplev_connections[i] *= 1.0-(temp*(max_oplev-oplev_connections[i])/max_oplev);
        //ale teraz może być już większe od max_oplev
        repairRepetition(sword->getWhichRepetition(i), oplev_connections[i]);
        setRepetitionForConnection(word_number, i, oplev_connections[i]);
    }
}
void Kurs::repairRepetition(ushort which_repetition, double oplev_connection) { //private
    double max_oplev = 20;
    double max_grade = 100;
    oplev_connection *= max_grade/max_oplev;
    repetitionsGrade[which_repetition] *= (double)repetitionsHowMany[which_repetition];
    repetitionsGrade[which_repetition] += oplev_connection;
    repetitionsHowMany[which_repetition]++;
    repetitionsGrade[which_repetition] /= (double)repetitionsHowMany[which_repetition];
    if(repetitionsGrade[which_repetition] > max_grade*0.95) {
        double time = (double)repetitionsTime[which_repetition];
        time *= 0.95/0.90;
        repetitionsTime[which_repetition] = (unsigned int)time;
        repetitionsHowMany[which_repetition] = 0;
        repetitionsGrade[which_repetition] = 0;
    }
    else if(repetitionsGrade[which_repetition] < 0.8) {
        double time = (double)repetitionsTime[which_repetition];
        time *= 0.8/0.9;
        repetitionsTime[which_repetition] = (unsigned int)time;
        repetitionsHowMany[which_repetition] = 0;
        repetitionsGrade[which_repetition] = 0;
    }
}
void Kurs::setRepetitionForConnection(ushort word_number, ushort nr_connection, double oplev_connection) { //private
    double max_oplev = 20;
    SingleWord *sword = word_number < wordl1.size() ? wordl1[word_number] : wordl2[word_number-wordl1.size()];
    ushort repetition = sword->getWhichRepetition(nr_connection);
    if(oplev_connection > max_oplev*0.9) {
        repetition++;
        if(repetition = repetitionsTime.size()) {
            repetitionsTime.push_back(repetitionsTime[repetition-1]*2);
            repetitionsHowMany.push_back(0);
            repetitionsGrade.push_back(0);
        }
    }
    else if(oplev_connection < max_oplev*0.5){
        if(repetition != 0) {
            repetition--;
        }
    }
    
}
void Kurs::setSingleWord(ushort number, string spelling, string sound) {
    if(number >= qAllWords)throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
    SingleWord *sword = number < wordl1.size() ? wordl1[number] : wordl2[number-wordl1.size()];
    sword->setSpelling(spelling);
    sword->setSound(sound);
}
void Kurs::takeOutSWFromLine(vector<string> &spellings, vector<string> &sounds, string rest) {
    size_t found=rest.find('|');
    if(found == string::npos)
    {
        if(rest != "") {
            spellings.push_back(rest);
            sounds.push_back("");
        }
    }
    else if(found == 0)takeOutSWFromLine(spellings, sounds, rest.substr(1));
    else {
        spellings.push_back(rest.substr(0, found));
        sounds.push_back("");
        takeOutSWFromLine(spellings, sounds, rest.substr(found+1));
    }
}
string Kurs::readSingleWordsFromFile(string file_to_open)
{
	ifstream plik;
	plik.open(file_to_open.c_str(), ios::binary);
	if(!plik.is_open())throw Error::newError(Error::ERROR_OPEN_FILE, "", __LINE__, __FILE__);
	string message;
	ushort number_of_words;
	plik >> number_of_words;
	string clear_buf; //zostaje biały znak po ilości słów
	getline(plik, clear_buf);
        string line;
	for(ushort i = 0; i < number_of_words; i++)
	{
		getline(plik, line);
                if(plik.eof())throw Error::newError(Error::ERROR_READ_FILE, "", __LINE__, __FILE__);
                size_t found=line.find('\t');
                if(found == string::npos)
                {
                    message += "IGNORED: " + line + "\n";
                    continue;
                }
                if(found == line.length()-1 || found == 0) {
                    message += "IGNORED: " + line + "\n";
                    continue;
                }
                message += "READ: " + line + "\n";
		vector<string> spellings;
                vector<string> meanings_spelling;
                vector<string> sounds;
                vector<string> meanings_sound;
                takeOutSWFromLine(spellings, sounds, line.substr(0, found));
                takeOutSWFromLine(meanings_spelling, meanings_sound, line.substr(found+1));
                addSingleWords(spellings, sounds, meanings_spelling, meanings_sound);
	}
        qAllSingleWords = wordl1.size() + wordl2.size();
	plik.close();
        return message;
}
void Kurs::unitSingleWords(ushort number1, ushort number2) {
    if(number1 >= qAllSingleWords || number2 >= qAllSingleWords)throw Error::newError(Error::BAD_ARGUMENT, "",__LINE__, __FILE__);
    if(number1 >= wordl1.size() && number2 >= wordl1.size()) {
        wordl2[number1]->joinOtherSingleWord(wordl2[number2]);
        if(wordl2[number2]->getOplev() != 0)qKnownSingleWords--;
        wordl2.erase(wordl2.begin() + number2);
    }
    else if(number1 < wordl1.size() && number2 < wordl1.size()) {
        wordl1[number1]->joinOtherSingleWord(wordl1[number2]);
        if(wordl1[number2]->getOplev() != 0)qKnownSingleWords--;
        wordl1.erase(wordl1.begin() + number2);
    }
    qAllSingleWords = wordl1.size() + wordl2.size();
}


istream &operator >>(istream &str, Word &word)
{
	string line;
	size_t found;
	getline(str, line);
	found=line.find('\t');
	printf("%s\n", line.c_str());
	if(found == string::npos)
	{
		str.clear(str.rdstate() | ios::failbit);
	}
	if(found == 0)word.setFirst("");
	else word.setFirst(line.substr(0, found));
	if(found == line.length()-1)word.setSecond("");
	else word.setSecond(line.substr(found+1));
	return str;
}

Kurs::Kurs(const string &name, const string &lang1, const string &lang2, const string &filename, const ushort &askQKW, const ushort &askQNW,  RegisterOfErrors &_ROE)
{
	this->name = name;
	this->lang1 = lang1;
	this->lang2 = lang2;
	this->filename = filename;
	this->qAllWords = 0;
	this->qKnownWords = 0;
	this->askQKW = askQKW;
	this->askQNW = askQNW;
	this->ifChangeKurs = true;
	ROE = &_ROE;
}
Kurs::Kurs(string file_to_open,  RegisterOfErrors &_ROE, ushort version)
{
    ROE = &_ROE;
    if(version == 0) {
        FILE *plik;
        plik = fopen(file_to_open.c_str(), "r");
	if(plik == NULL)throw Error::newError(Error::ERROR_OPEN_FILE, "Kurs::Kurs(string file_to_open)", __LINE__, __FILE__);
	ifChangeKurs = false;
	//początek wczytywania danych kursu
	char _name[100];
	fscanf(plik, "%s", _name);
	name = decode_text(_name);
	char _lang1[100], _lang2[100];
	fscanf(plik, "%s %s", _lang1, _lang2);
	lang1 = decode_text(_lang1);
	lang2 = decode_text(_lang2);
	char _filename[100];
	fscanf(plik, "%s %hu %hu", _filename, &askQKW, &askQNW);
	filename = decode_text(_filename);
	fscanf(plik, "%hu %hu", &qAllWords, &qKnownWords);
	//koniec wczytywania danych kursu
	ushort _hralev, _oplev;
	unsigned int _time_lastud;
	Word *word = new Word();//przeciążyć wczytywanie do Word, oraz zmienić przeciążanie do Word na przeciążanie do pair_string
	for(ushort i = 0; i < qAllWords; i++)
	{
		char _first[100], _second[100];
		fscanf(plik, "%s\t%s\t%hu %hu %u\n", _first, _second, &_hralev, &_oplev, &_time_lastud);
		word->setFirst(decode_text(_first));
		word->setSecond(decode_text(_second));
		word->setHralev(_hralev);
		word->setOplev(_oplev);
		word->setTime_lastud(_time_lastud);
		this->words.push_back(*word);
	}
        
        //restore memory
        delete plik;
        delete word;
    }
    else {
        
        ifstream file;
        file.open(file_to_open.c_str());
        if(!file.is_open())throw Error::newError(Error::ERROR_OPEN_FILE, "", __LINE__, __FILE__);
        string firstline;
        getline(file, firstline);
        if(firstline == "new version") {
            ushort numberWordsFL;
            ushort numberWordsSL;
            file >> name;
            file.ignore(INT_MAX, '\n');
            file >> numberWordsFL;
            file.ignore(INT_MAX, '\n');
            file >> numberWordsSL;
            file.ignore(INT_MAX, '\n');
            file >> numberConnections;
            file.ignore(INT_MAX, '\n');
            file >> askQKW;
            file.ignore(INT_MAX, '\n');
            file >> askQNW;
            file.ignore(INT_MAX, '\n');
            ushort qRepetition;
            file >> qRepetition;
            file.ignore(INT_MAX, '\n');
            unsigned int repetitionTime;
            ushort repetitionHowMany;
            double repetitionGrade;
            for(int i = 0; i < qRepetition; i++) {
                file >> repetitionTime;
                file >> repetitionHowMany;
                file >> repetitionGrade;
                file.ignore(INT_MAX, '\n');
                repetitionsTime.push_back(repetitionTime);
                repetitionsHowMany.push_back(repetitionHowMany);
                repetitionsGrade.push_back(repetitionGrade);
            }
            filename = file_to_open;
            qAllSingleWords = numberWordsFL + numberWordsSL;
            
            SingleWord sword("", "");
            ushort oplev;
            ushort hralev;
            string spelling;
            unsigned int time_lastud;
            time_t nowTime = time(NULL);
            qKnownSingleWords = 0;
            ifChangeKurs = false;
            for(ushort i = 0; i < numberWordsFL; i++) {
                getline(file, spelling);
                file >> oplev;
                file >> hralev;
                file >> time_lastud;
                file.ignore(INT_MAX, '\n');
                sword.setSpelling(spelling);
                sword.setHralev(hralev);
                sword.setTime_lastud(time_lastud);
                sword.setOplev(oplev);
                sword.setOplev(nowTime);
                if(oplev != sword.getOplev())ifChangeKurs = true;
                wordl1.push_back(new SingleWord(sword));
            }
            for(ushort i = 0; i < numberWordsSL; i++) {
                getline(file, spelling);
                file >> oplev;
                file >> hralev;
                file >> time_lastud;
                file.ignore(INT_MAX, '\n');
                sword.setSpelling(spelling);
                sword.setHralev(hralev);
                sword.setTime_lastud(time_lastud);
                sword.setOplev(oplev);
                sword.setOplev(nowTime);
                if(oplev != sword.getOplev())ifChangeKurs = true;
                wordl2.push_back(new SingleWord(sword));
            }
            ushort number1;
            ushort number2;
            ushort which_repetition;
            ushort last_repetition;
            for(ushort i = 0; i < numberConnections; i++) {
                file >> number1;
                file >> number2;
                file >> which_repetition;
                file >> last_repetition;
                file.ignore(INT_MAX, '\n');
                if(number1 >= wordl1.size() || (number2 >= wordl1.size()+wordl2.size() || number2 < wordl1.size()))throw Error::newError(Error::BAD_ARGUMENT, "", __LINE__, __FILE__);
                SingleWord::connectSingleWords(wordl1[number1], wordl2[number2-wordl1.size()], which_repetition, last_repetition);
                //to samo co: connectSingleWords(number1, number2);
            }
            for(ushort i = 0; i < numberWordsFL; i++) {
                if(wordl1[i]->isKnown())qKnownSingleWords++;
            }
            for(ushort i = 0; i < numberWordsSL; i++) {
                if(wordl2[i]->isKnown())qKnownSingleWords++;
            }
            file.close();
        }
        else {
            file.close();
            FILE *plik;
            plik = fopen(file_to_open.c_str(), "r");
            if(plik == NULL)throw Error::newError(Error::ERROR_OPEN_FILE, "Kurs::Kurs(string file_to_open)", __LINE__, __FILE__);
            ifChangeKurs = false;
            //początek wczytywania danych kursu
            char _name[100];
            fscanf(plik, "%s", _name);
            name = decode_text(_name);
            char _lang1[100], _lang2[100];
            fscanf(plik, "%s %s", _lang1, _lang2);
            lang1 = decode_text(_lang1);
            lang2 = decode_text(_lang2);
            char _filename[100];
            fscanf(plik, "%s %hu %hu", _filename, &askQKW, &askQNW);
            //filename = decode_text(_filename);
            filename = file_to_open;
            fscanf(plik, "%hu %hu", &qAllSingleWords, &qKnownSingleWords);
            qKnownSingleWords = 0;
            numberConnections = qAllSingleWords;
            qAllSingleWords *= 2;
            
            repetitionsTime.push_back(3600*24);
            repetitionsHowMany.push_back(0);
            repetitionsGrade.push_back(0.0);
            
            //koniec wczytywania danych kursu
            ushort _hralev, _oplev;
            unsigned int _time_lastud;
            SingleWord sword("", "");
            time_t nowTime = time(NULL);
            for(ushort i = 0; i < numberConnections; i++) {
		char _first[100], _second[100];
		fscanf(plik, "%s\t%s\t%hu %hu %u\n", _first, _second, &_hralev, &_oplev, &_time_lastud);
		sword.setSpelling(decode_text(_first));
		sword.setHralev(_hralev);
		sword.setTime_lastud(_time_lastud);
                sword.setOplev(_oplev);
                sword.setOplev(nowTime);
                if(_oplev != sword.getOplev())ifChangeKurs = true;
                if(sword.getOplev() != 0)qKnownSingleWords += 2;
                wordl1.push_back(new SingleWord(sword));
                sword.setSpelling(decode_text(_second));
                wordl2.push_back(new SingleWord(sword));
                SingleWord::connectSingleWords(wordl1[i], wordl2[i], 0, _time_lastud);
            }
            delete plik;
            //restore memory
            
        }
    }
}
void Kurs::addWord(string first, string second)
{
	if(this->qAllWords >= 65535)
	{
		throw Error::newError(Error::OUTPASS_MAX_SIZE_OF_ARRAY, "void Kurs::addWord(string first, string second)", __LINE__, __FILE__);
	}
	words.push_back(Word::newWord(first, second));
	qAllWords = words.size();
	ifChangeKurs = true;
}
void Kurs::addWord(Word &word)
{
	if(this->qAllWords >= 65535)
	{
		throw Error::newError(Error::OUTPASS_MAX_SIZE_OF_ARRAY, "void Kurs::addWord(Word word)", __LINE__, __FILE__);
	}
	words.push_back(word);
	qAllWords = words.size();
	ifChangeKurs = true;
}
void Kurs::aktualizuj()
{
	time_t nowTime;
	ifChangeKurs = true;
	nowTime = time(NULL);
	qKnownWords = 0;
	for(ushort i = 0; i < qAllWords; i++)
	{
		words[i].setOplev(nowTime);
		if(words[i].getOplev() != 0)qKnownWords++;	
	}
}
ushort Kurs::compare_words(string aa, string bb)
{
	ushort a = aa.length();
	ushort b = bb.length();
				
	ushort **tablice = new ushort*[2];
	tablice[0] = new ushort[a+1];
	tablice[1] = new ushort[a+1];

	tablice[0][0] = 1;
	for(ushort i = 1; i <= a; i++)
	{
		if(bb[0] == aa[i-1])
		{
			tablice[0][i] = i-1;
		}
		else
		{
			if(tablice[0][i-1] < i-1)tablice[0][i] = tablice[0][i-1]+1;
			else tablice[0][i] = i;
		}
	}
	ushort *temp;
	for(ushort i = 1; i < b; i++)
	{
		tablice[1][0] = i+1;
		for(ushort j = 1; j <= a; j++)
		{
			if(bb[i] == aa[j-1])
			{
				tablice[1][j] = tablice[0][j-1];
			}
			else
			{
				if(tablice[0][j] < tablice[1][j-1] && tablice[0][j] < tablice[0][j-1])tablice[1][j] = tablice[0][j]+1;
				else if(tablice[1][j-1] < tablice[0][j] && tablice[1][j-1] < tablice[0][j-1])tablice[1][j] = tablice[1][j-1]+1;
				else tablice[1][j] = tablice[0][j-1]+1;
			}
		}
		temp = tablice[0];
		tablice[0] = tablice[1];
		tablice[1] = temp;
	}
        //restore memory
        ushort wynik = tablice[0][a];
        delete [] tablice[0];
        delete [] tablice[1];
        
	return wynik;
}
string Kurs::decode_text(string oryginal)
{
	string wynik = "";
	for(int i = 0; i < oryginal.length(); i++)
	{
		if(oryginal[i] == '&')
		{
			wynik += (char)((oryginal[i+1]-'0')*10+(oryginal[i+2]-'0'));
			i+=2;
		}
		else
		{
			wynik += oryginal[i];
		}
	}
	return wynik;
}
void Kurs::delWord(ushort number)
{
	if(number >= this->qAllWords)
	{
		throw Error::newError(Error::OUTPASS_ABOVE_SPACE_OF_ARRAY, "void delWord(ushort number)", __LINE__, __FILE__);
	}
	words.erase(words.begin()+number);
	qAllWords = words.size();
	ifChangeKurs = true;
}
string Kurs::encode_text(string oryginal)
{
	string wynik = "";
	for(int i = 0; i < oryginal.length(); i++)
	{
		if(oryginal[i] == '&')wynik += "&38";
		else if(oryginal[i] < 33)
		{
			wynik += "&";
			wynik += (char)(oryginal[i]/10+'0');
			wynik += (char)(oryginal[i]%10+'0');
		}
		else
		{
			wynik += oryginal[i];
		}
	}
	return wynik;
}
vector<ushort> Kurs::findWord(boost::regex searched_string) const
{
	vector<ushort> found_words;
	for(ushort i = 0; i < qAllWords; i++)
	{
		if(regex_match(words[i].getFirst(), searched_string) || regex_match(words[i].getSecond(), searched_string))
		{
			found_words.push_back(i);
		}
	}
	return found_words;
}
vector<ushort> Kurs::getUnknownWords(ushort quantityOfWords) const
{
	if(quantityOfWords > this->qAllWords - this->qKnownWords)quantityOfWords = this->qAllWords - this->qKnownWords;
	vector<ushort> wordsToAsk;
	for(ushort i = 0, j = 0; i < this->qAllWords && j < quantityOfWords; i++)
	{
		if(words[i].getOplev() == 0)
		{
			wordsToAsk.push_back(i);
			j++;
		}
	}
	return wordsToAsk;
}
vector<ushort> Kurs::getKnownWords(ushort quantityOfWords) const
{
	if(quantityOfWords > qKnownWords)quantityOfWords = qKnownWords;
	priority_queue<WordAndNumber, vector<WordAndNumber>, compareWord> Q;
	WordAndNumber wan;
	for(ushort i = 0; i < qAllWords; i++)
	{
		if(words[i].getOplev() != 0)
		{
			wan.slowo = &words[i];
			wan.number = i;
			Q.push(wan);
		}
	}
	vector<ushort> wordsToAsk;
	for(ushort i = 0; i < quantityOfWords; i++)
	{
		wordsToAsk.push_back(Q.top().number);
		Q.pop();
	}
	return wordsToAsk;
}
string Kurs::getName() const
{
		return this->name;
}
string Kurs::getLang1() const
{
	return this->lang1;
}
string Kurs::getLang2() const
{
	return this->lang2;
}
string Kurs::getFilename() const
{
	return this->filename;
}
bool Kurs::isKursChanged() const
{
	return this->ifChangeKurs;
}
ushort Kurs::getQAllWords() const
{
	return this->qAllWords;
}
ushort Kurs::getQKnownWords() const
{
	return this->qKnownWords;
}
ushort Kurs::getAskQKW() const
{
	return this->askQKW;
}
ushort Kurs::getAskQNW() const
{
	return this->askQNW;
}
Word Kurs::getWord(ushort number) const
{
	if(number >= this->qAllWords)
	{
		throw Error::newError(Error::BAD_ARGUMENT, "Word Kurs::getWord(ushort number)", __LINE__, __FILE__);
	}
	return this->words[number];
}
vector<Word> Kurs::getWords(ushort &from, ushort &_to) const
{
	vector<Word> _words;
	if(from >= this->qAllWords || _to >= this->qAllWords)
	{
		throw Error::newError(Error::OUTPASS_ABOVE_SPACE_OF_ARRAY, "vector<Word> Kurs::getWords(ushort &from, ushort &_to)", __LINE__, __FILE__);
	}
	if(_to < from && _to != 0)
	{
		throw Error::newError(Error::BAD_ARGUMENT, "vector<Word> Kurs::getWords(ushort &from, ushort &_to)", __LINE__, __FILE__);
	}
	if(_to == 0)_to = qAllWords-1;
	for(ushort i = from; i <= _to; i++)
	{
		_words.push_back(words[i]);
	}
	return _words;
}
void Kurs::increaseQKnownWords(short int quantity)
{
	qKnownWords += quantity;
}
void Kurs::readWordsFromFile(string file_to_open)
{
	ifstream plik;
	plik.open(file_to_open.c_str(), ios::binary);
	if(!plik.is_open())throw Error::newError(Error::ERROR_SAVE_FILE, "void Kurs::readWordsFromFile(string file_to_open)", __LINE__, __FILE__);
	
	ushort number_of_words;
	Word *word = new Word();
	plik >> number_of_words;
	string clear_buf; //zostaje biały znak po ilości słów
	getline(plik, clear_buf);
	for(ushort i = 0; i < number_of_words; i++)
	{
		plik >> *word;
		if(plik.fail())
		{
			plik.clear(plik.rdstate() & ~ios::failbit);
			ROE->addError(Error::newError(Error::IGNORED_LINE_IN_FILE, "void Kurs::readWordsFromFile(string file_to_open)", __LINE__, __FILE__));
			continue;
		}
		if(plik.eof())throw Error::newError(Error::ERROR_READ_FILE, "void Kurs::readWordsFromFile(string file_to_open)", __LINE__, __FILE__);
		addWord(*word);
	}
	plik.close();
        delete word;
}
void Kurs::repairWord(ushort numberOfWords, ushort krakl, double czas, double oplev)
{
	//krakl is number of word in element Word, what user wrote
	//now is allowed for number 0 and 1, where 0 marks word in first language, 1 marks word in second language
	if(krakl == 0)czas /= words[numberOfWords].getFirst().length();
	else if(krakl == 1)czas /= words[numberOfWords].getSecond().length();
	
	if(oplev > 1000)oplev = 1000;
	oplev /= czas;
	int procent = (((words[numberOfWords].getOplev()*1000)/oplev)-1000)/2;
	
	words[numberOfWords].setHralev((words[numberOfWords].getHralev()*procent)/1000+words[numberOfWords].getHralev());
	words[numberOfWords].setOplev((ushort)oplev);
	words[numberOfWords].setTime_lastud(time(NULL));
	
        if(oplev == 0)increaseQKnownWords(-1);
	ifChangeKurs = true;
}
void Kurs::saveKurs(string file_to_save, ushort version)
{
    if(version == 0) {
        FILE *plik;
        plik = fopen(file_to_save.c_str(), "w");
	if(plik == NULL)throw Error::newError(Error::ERROR_SAVE_FILE, "Kurs::Kurs(string file_to_open)", __LINE__, __FILE__);
	this->ifChangeKurs = false;
	fprintf(plik, "%s\n", encode_text(name).c_str());
	fprintf(plik, "%s\t%s\n", encode_text(lang1).c_str(), encode_text(lang2).c_str());
	fprintf(plik, "%s\t%hu %hu\n", encode_text(file_to_save).c_str(), askQKW, askQNW);
	fprintf(plik, "%hu %hu\n", qAllWords, qKnownWords);
		
	for(ushort i = 0; i < qAllWords; i++)
	{
		fprintf(plik, "%s\t%s\t%hu %hu %u\n", encode_text(words[i].getFirst()).c_str(), encode_text(words[i].getSecond()).c_str(), words[i].getHralev(), words[i].getOplev(), words[i].getTime_lastud());
	}
	fclose(plik);
        delete plik;
    }
    else {
        ofstream file;
        file.open(file_to_save.c_str());
        if(!file.is_open())throw Error::newError(Error::ERROR_OPEN_FILE, "", __LINE__, __FILE__);
        file << "new version" << endl;
        file << name << endl;
        file << wordl1.size() << endl;
        file << wordl2.size() << endl;
        file << numberConnections << endl;
        file << askQKW << endl;
        file << askQNW << endl;
        file << repetitionsTime.size() << endl; //dać zmienną rozmiaru
        for(int i = 0; i < repetitionsTime.size(); i++) {
            file << repetitionsTime[i] << "\t";
            file << repetitionsHowMany[i] << "\t";
            file << repetitionsGrade[i];
            file << endl;
        }
        for(ushort i = 0; i < wordl1.size(); i++) {
            file << wordl1[i]->getSpelling() << endl;
            file << wordl1[i]->getOplev() << "\t";
            file << wordl1[i]->getHralev() << "\t";
            file << wordl1[i]->getTime_lastud() << endl;
        }
        for(ushort i = 0; i < wordl2.size(); i++) {
            file << wordl2[i]->getSpelling() << endl;
            file << wordl2[i]->getOplev() << "\t";
            file << wordl2[i]->getHralev() << "\t";
            file << wordl2[i]->getTime_lastud() << endl;
            wordl2[i]->id = i+wordl1.size();
        }
        for(ushort i = 0; i < wordl1.size(); i++) {
            for(ushort j = 0; j < wordl1[i]->getNumberMeanings(); j++) {
                file << i << "\t";
                file << wordl1[i]->getMeaning(j)->id << "\t";
                file << wordl1[i]->getWhichRepetition(j) << "\t";
                file << wordl1[i]->getTimeLastRepetition(j) << endl;
            }
        }
        file.close();
    }
}
void Kurs::setName(string _name)
{
	name = _name;
	ifChangeKurs = true;
}
void Kurs::setLang1(string _lang1)
{
	lang1 = _lang1;
	ifChangeKurs = true;
}
void Kurs::setLang2(string _lang2)
{
	lang2 = _lang2;
	ifChangeKurs = true;
}
void Kurs::setFilename(string _filename)
{
	filename = _filename;
	ifChangeKurs = true;
}
void Kurs::setIfChangeKurs(bool _ifChangeKurs)
{
	ifChangeKurs = _ifChangeKurs;
}
void Kurs::setAskQKW(ushort _askQKW)
{
	askQKW = _askQKW;
	ifChangeKurs = true;
}
void Kurs::setAskQNW(ushort _askQNW)
{
	askQNW = _askQNW;
	ifChangeKurs = true;
}
void Kurs::setWord(ushort number, string first, string second)
{
	if(number >= this->qAllWords)
	{
		throw Error::newError(Error::OUTPASS_ABOVE_SPACE_OF_ARRAY, "void setWord(ushort number, string first, string second)", __LINE__, __FILE__);
	}
	words[number].setFirst(first);
	words[number].setSecond(second);
	ifChangeKurs = true;
}